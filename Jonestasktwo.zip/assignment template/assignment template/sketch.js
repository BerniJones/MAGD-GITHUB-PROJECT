function setup() {
createCanvas(500, 500);
background(125);
angleMode(DEGREES);
}

function draw() {
background(220);
colorMode(RGB, 255, 255, 255, 1);
stroke(5);

fill(118, 97, 54);
beginShape();
vertex(2, 311);
vertex(53, 364);
vertex(143, 388);
vertex(149, 365);
vertex(180, 365);
vertex(189, 375);
vertex(195, 390);
vertex(230, 450);
vertex(430, 390);
vertex(500, 500);
vertex(2, 500);
endShape(CLOSE);

noStroke();
fill(253, 143, 0);
arc(420, 101, 269, 299, 90, 80 );
quad(290, 140, 500, 105, 522, 320, 422, 320);

fill(3, 170, 242);
ellipse(124, 113, 35, 40);

fill(6, 114, 16);
ellipse(230, 283, 50, 60);

stroke(20);
line(309, 181, 480, 393);

fill(10);
quad(450, 391, 500, 391, 500, 439, 484, 439);
rect(220, 336, 20, 20);
line(105, 113, 118, 142);
line(125, 123, 128, 152);
line(140, 113, 138, 142);
line(210, 302, 228, 357);
line(230, 302, 228, 357);
line(250, 302, 234, 357);
triangle(113, 139, 130, 157, 145, 134);

noFill();
stroke(219, 15, 15);
curve(44, 373, 55, 87, 247, 37, 409, 184);
stroke(7, 4, 120);
fill(37, 154, 217);
quad(32, 86, 54, 50, 83, 73, 58, 110);
fill(217, 193, 37);
triangle(58, 110, 48, 73, 83, 73);
fill(217, 67, 37);
triangle(32, 86, 48, 73, 58, 110);
fill(131, 189, 113);
triangle(32, 86, 54, 50, 48, 73);
  
}