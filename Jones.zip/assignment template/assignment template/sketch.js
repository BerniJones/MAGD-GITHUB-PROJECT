function setup() {
createCanvas(500, 500);
strokeWeight(2.8)
}

function draw() {
background(150);

const e = color(240, 240, 240, 102);
fill(e);
ellipse(278, 60, 50, 50)

fill(220)
ellipse(278, 60, 40, 40)
fill(10)
line(60, 60, 110, 110)
rect(10, 60, 50, 300)
fill(220)
rect(40, 80, 10, 10)
rect(20, 80, 10, 10)
rect(40, 100, 10, 10)
rect(20, 100, 10, 10)
rect(40, 120, 10, 10)
rect(20, 120, 10, 10)
rect(40, 140, 10, 10)
rect(20, 140, 10, 10)
rect(40, 160, 10, 10)
rect(20, 160, 10, 10)
rect(40, 180, 10, 10)
rect(20, 180, 10, 10)
rect(40, 200, 10, 10)
rect(20, 200, 10, 10)
rect(40, 220, 10, 10)
rect(20, 220, 10, 10)
rect(40, 260, 10, 10)
rect(20, 260, 10, 10)
rect(40, 280, 10, 10)
rect(20, 280, 10, 10)
fill(90)
rect(1, 350, 500, 22)
fill(125)
rect(100, 120, 60, 230)
fill(40)
rect(90, 120, 60, 230)
fill(80)
rect(80, 150, 50, 200)
fill(60)
rect(70, 150, 50, 200)
fill(182)
rect(128, 130, 10, 10)
rect(100, 130, 10, 10)
fill(245)
rect(100, 160, 10, 10)
rect(77, 160, 10, 10)
fill(182)
rect(100, 180, 10, 10)
fill(245)
rect(77, 180, 10, 10)
rect(100, 200, 10, 10)
rect(77, 220, 10, 10)
fill(182)
rect(100, 240, 10, 10)

const c = color(245, 245, 245, 102);
fill(c);
triangle(275, 115, -140, 480, 840, 660)

fill(115)
rect(240, 115, 80, 305)
fill(45)
rect(175, 185, 100, 400)

fill(115)
rect(59, 310, 80, 205)
fill(45)
rect(40, 315, 80, 205)

fill(245)
strokeJoin(BEVEL);
rect(235, 200, 30, 55)
rect(185, 200, 30, 55)
rect(235, 280, 30, 55)
rect(185, 280, 30, 55)
rect(235, 360, 30, 55)
rect(185, 360, 30, 55)
rect(235, 440, 30, 55)
rect(185, 440, 30, 55)

fill(98)
strokeJoin(BEVEL);
rect(305, 215, 200, 300)
  
noFill()
ellipse(225,120, 7, 7)
ellipse(125,80, 7, 7)
ellipse(325,90, 7, 7)
ellipse(425,100, 7, 7)
ellipse(375,160, 7, 7)
ellipse(455,190, 7, 7)
ellipse(475, 40, 7, 7)
ellipse(375, 25, 7, 7)
ellipse(275, 20, 7, 7)
ellipse(185, 45, 7, 7)
ellipse(105, 20, 7, 7)
ellipse(275, 20, 7, 7)
ellipse(55, 35, 7, 7)

}