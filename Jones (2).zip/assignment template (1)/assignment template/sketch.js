function setup() {
  createCanvas(490, 400);
  angleMode(RADIANS);
  colorMode(RGB);
  var yesterdaysTemp = -11;
  var todaysTemp = calculateTemp(yesterdaysTemp);
  print(todaysTemp);
}

function calculateTemp(t){
  var newTemp = t * 0.38;
  return newTemp;
}

function draw() {
  background(220);
  for( var x = 35; x < width + 70; x += 70){
    snowman(x, 240);
    
  }
  
  snowman(110,110);
  snowman(200,120);
}

function snowman(x,y){
  push();
  translate(x, y);
  stroke(0);
  strokeWeight(2);
  fill(204, 255, 255);
  scale(mouseX / 100);
  rotate(mouseX / 10);
  ellipse(50, 50, 50, 50);
  ellipse(50, 110, 70, 70);
  fill(255, 204, 153);
  triangle(40, 40, 60, 60, 10, 70);
  
  pop();
  print('Its cold outside');
}